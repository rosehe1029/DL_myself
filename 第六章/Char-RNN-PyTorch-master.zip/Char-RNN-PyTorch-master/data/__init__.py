# encoding: utf-8
"""
@author: xyliao
@contact: xyliao1993@qq.com
"""
from .dataset import TextConverter, TextDataset
