# encoding: utf-8
"""
@author: xyliao
@contact: xyliao1993@qq.com
"""
from .char_rnn import CharRNN
