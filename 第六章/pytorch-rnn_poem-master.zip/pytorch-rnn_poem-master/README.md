# pytorch-rnn_poem
使用pytorch，简单rnn模型写诗


没有加 embedding层，直接one-hot输入的，可以优化，这只是写五言藏头诗， 如果想写七言或者其他，可以自己修改模型。

只需要看data.ipynb这个文件就ok，95%代码都在这个文件里面了。
